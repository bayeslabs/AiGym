# Markov Chain Startercode

Starter code for [www.stanford.edu/~schmit/cme193](CME 193) assignment.

## Data
Book data from https://www.gutenberg.org/