# Rock paper scissors startercode

Starter code for [CME 193](www.stanford.edu/~schmit/cme193) assignment.