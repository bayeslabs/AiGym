Hangman implementation
======================

Simple Python implementation of Hangman for [CME 193](www.stanford.edu/~schmit/cme193) demo.

